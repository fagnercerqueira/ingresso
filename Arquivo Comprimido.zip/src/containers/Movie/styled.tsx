import styled from 'styled-components';

export const AppContainer = styled.div`

`;
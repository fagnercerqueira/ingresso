import styled from 'styled-components';
// import Theme from '../../utils/Theme';
export const MovieListContainer = styled.div`
   
`;

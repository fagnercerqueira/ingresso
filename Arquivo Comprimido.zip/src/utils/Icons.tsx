import Logo from '../assets/icons/ingresso.svg';
import IconPin from '../assets/icons/pin.svg';
import IconSearch from '../assets/icons/search.svg';
import IconClose from '../assets/icons/close.svg';
import IconArrowDown from '../assets/icons/arrow-down.svg';

export {
    Logo,
    IconPin,
    IconSearch,
    IconClose,
    IconArrowDown
};
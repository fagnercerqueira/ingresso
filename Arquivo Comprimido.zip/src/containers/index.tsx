import App from './App';
import Notfound from './NotFound';
import Movie from './Movie';
import Search from './Search';

export {App, Notfound, Movie, Search}